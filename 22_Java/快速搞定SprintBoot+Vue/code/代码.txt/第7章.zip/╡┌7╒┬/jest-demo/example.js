const add = (a,b)=>{
    return a + b;
}
//commonjs
module.exports = { add };