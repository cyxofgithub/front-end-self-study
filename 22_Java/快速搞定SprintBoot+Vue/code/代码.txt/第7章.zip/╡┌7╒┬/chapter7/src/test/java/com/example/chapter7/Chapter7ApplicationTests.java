package com.example.chapter7;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Chapter7ApplicationTests {

	@Test
	void contextLoads() {
	}

}
