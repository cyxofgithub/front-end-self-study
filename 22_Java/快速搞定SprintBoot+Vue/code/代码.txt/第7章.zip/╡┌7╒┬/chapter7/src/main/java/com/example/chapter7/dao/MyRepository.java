package com.example.chapter7.dao;


import org.springframework.stereotype.Repository;

@Repository
public class MyRepository {

    public String someMethod() {
        return "test";
    }
}
