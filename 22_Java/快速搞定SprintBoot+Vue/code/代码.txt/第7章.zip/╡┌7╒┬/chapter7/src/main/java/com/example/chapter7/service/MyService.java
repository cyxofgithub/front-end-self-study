package com.example.chapter7.service;

import com.example.chapter7.dao.MyRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class MyService {
    @Autowired
    MyRepository myRepository;

    public String performAction() {
        return myRepository.someMethod();
    }
}
