package com.example.chapter7;

import com.example.chapter7.dao.MyRepository;
import com.example.chapter7.service.MyService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class MyServiceTest {
    @Mock
    private MyRepository myRepository;

    @InjectMocks
    private MyService myService;
    // ... 测试方法 ...

    @Test
    public void testPerformAction() {
        // 设置模拟行为
        when(myRepository.someMethod()).thenReturn("test");
        // 调用服务层方法
        String result = myService.performAction();
        // 验证结果
        assertEquals("test", result);
        // 验证交互
        verify(myRepository).someMethod();
    }
}
