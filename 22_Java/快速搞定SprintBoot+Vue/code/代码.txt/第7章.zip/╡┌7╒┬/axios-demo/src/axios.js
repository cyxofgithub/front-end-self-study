import axios from 'axios';
const axiosInstance = axios.create({
  baseURL: 'http://localhost:8080' // 替换为API 基础 URL
});
export default axiosInstance;

