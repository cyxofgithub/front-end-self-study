<script setup>
import { ref, getCurrentInstance, onMounted } from 'vue';
const responseData = ref(null);

const { proxy } = getCurrentInstance(); // 获取组件实例

const fetchData = async () => {
    try {
        // 使用相对路径，baseURL 会自动加上
        const response = await proxy.$axios.get('/test');
        responseData.value = response.data; // 存储响应数据
    } catch (error) {
        console.error('Error fetching data:', error); // 处理错误
    }
};

onMounted(()=>{
    fetchData(); 
})

</script>

<template>
    <p>{{responseData}}</p>
</template>

<style scoped></style>
