package com.example.chapter3.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.chapter3.model.Employee;

public interface EmployeeMapper extends BaseMapper<Employee> {


}
