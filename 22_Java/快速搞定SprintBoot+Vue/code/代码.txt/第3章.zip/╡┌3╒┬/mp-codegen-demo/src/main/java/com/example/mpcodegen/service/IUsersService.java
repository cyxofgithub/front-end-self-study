package com.example.mpcodegen.service;

import com.example.mpcodegen.entity.Users;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author liu
 * @since 2024-06-02
 */
public interface IUsersService extends IService<Users> {

}
