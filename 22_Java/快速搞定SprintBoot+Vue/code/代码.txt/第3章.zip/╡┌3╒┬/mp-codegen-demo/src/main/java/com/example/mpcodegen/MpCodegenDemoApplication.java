package com.example.mpcodegen;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MpCodegenDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(MpCodegenDemoApplication.class, args);
	}

}
