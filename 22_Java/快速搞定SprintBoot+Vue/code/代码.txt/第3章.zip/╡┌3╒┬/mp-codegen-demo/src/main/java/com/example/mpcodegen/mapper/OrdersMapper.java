package com.example.mpcodegen.mapper;

import com.example.mpcodegen.entity.Orders;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author liu
 * @since 2024-06-02
 */
public interface OrdersMapper extends BaseMapper<Orders> {

}
