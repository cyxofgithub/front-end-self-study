package com.example.mpcodegen.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author liu
 * @since 2024-06-02
 */
@RestController
@RequestMapping("/users")
public class UsersController {

}
