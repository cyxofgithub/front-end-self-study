// defaultGreeting.js 
export default "Hello, World!";
