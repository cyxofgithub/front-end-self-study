// main.js 
import { message, sayHello } from './message.js';
import defaultGreeting from './defaultGreeting.js';

console.log(message);             // 输出： "Hello from module"
console.log(sayHello('Vue'));   // 输出： "Hello, Vue!"
console.log(defaultGreeting);   // 输出： "Hello, World!"