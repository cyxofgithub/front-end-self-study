// message.js 
export const message = "Hello from module";
export function sayHello(name) {
    return `Hello, ${name}!`;
}
