<template>
<div class="hello-world">
    <h1>{{ message }}</h1>
</div>
</template>

<script>
export default {
data() {
    return {
    message: "Hello, Vue 3!"
    };
}
}
</script>

<style>
.hello-world {
color: blue;
}
</style>
  