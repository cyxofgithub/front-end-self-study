<script setup>
</script>

<template>
	<div id="app" style="margin:0;padding: 0;height: 100%;">
		<router-view></router-view>
	</div>
</template>

<style>


	body {
		margin: 0;
		padding: 0;
	}


</style>
