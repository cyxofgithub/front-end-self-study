# 在线考试系统后端

***

## 项目构建
**运行**：

在终端输入`mvn install`下载依赖，然后运行ExamSystemApplication类

**打包**：

在终端输入`mvn package`获得jar包，使用java -jar xxx.jar即可在8081端口运行

***

## 功能模块

登陆注册

班级管理

考试管理

考试过程

批阅管理

成绩管理

***

## 接口文档
项目地址 + swagger-ui.html
