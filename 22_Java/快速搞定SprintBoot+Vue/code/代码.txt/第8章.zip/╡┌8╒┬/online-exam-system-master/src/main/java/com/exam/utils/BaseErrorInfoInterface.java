package com.exam.utils;

public interface BaseErrorInfoInterface {
    String getResultCode();
    String getResultMsg();
}
