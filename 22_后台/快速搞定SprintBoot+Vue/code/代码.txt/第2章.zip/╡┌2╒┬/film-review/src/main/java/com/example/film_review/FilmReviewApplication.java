package com.example.film_review;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FilmReviewApplication {

	public static void main(String[] args) {
		SpringApplication.run(FilmReviewApplication.class, args);
	}

}
