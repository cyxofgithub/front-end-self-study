package com.example.film_review;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FilmReviewApplicationTests {

	@Test
	void contextLoads() {
	}

}
