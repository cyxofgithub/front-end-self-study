package com.example.chapter1;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class MyAppProperties {

    //读取配置文件中的app.name配置项
    @Value("${app.name}")
    private String appName;

    public String getAppName() {
        return appName;
    }
    public void setAppName(String appName) {
        this.appName = appName;
    }
}
