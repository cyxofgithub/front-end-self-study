package com.example.chapter1;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Chapter1ApplicationTests {

	@Test
	void contextLoads() {
	}
	@Autowired
	private MyAppProperties appProperties;

	@Autowired
	private CustomProperties customProperties;

	@Test
	void getProperties(){
		System.out.println(appProperties.getAppName());;

		System.out.println(customProperties.getName());
		System.out.println(customProperties.getTimeout());
	}

}
